# Time Capsule Digital Memories — Sprints 1, 2 and 3

A complete cumulative Python Flask + SQLite project for local use.

Sprint 1: accounts, login/logout, frontend layout and dashboard.
Sprint 2: private drafts, photo/video attachments, cover colors, editing and confirmed deletion.
Sprint 3: opening dates, sealing, server-enforced time locks, live countdowns and unlocking.

## Start on Windows
1. Install Python 3.11 or newer and enable Add Python to PATH.
2. Extract the entire ZIP. Open the inner folder containing app.py.
3. Double-click start_windows.bat. Internet is needed for dependency installation.
4. Keep the terminal open and open http://127.0.0.1:5000 in Chrome.
5. Register or sign in, save a draft, then choose its opening date and seal it.

If the launcher fails, open Command Prompt in the project folder and run:
```
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```
If `py` is unavailable, use `python` for the first command. If port 5000 is in use, stop the old Time Capsule Digital Memories terminal first. If an error remains, copy the terminal error text; do not delete your database to troubleshoot.

macOS/Linux:
```
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

## Upgrade while keeping accounts and drafts
1. Stop your Sprint 2 application with Ctrl+C.
2. Back up the entire old project folder.
3. Extract this ZIP into a NEW folder.
4. COPY the entire old `instance/` folder into the new folder beside `app.py`. It contains the database, secret key and uploaded files. Keep the backup.
5. Run the new launcher. Missing Sprint 3 database columns are added automatically; existing data remains.

This migration supports the supplied Sprint 1 and Sprint 2 project versions. Do not use the separate original complete Time Capsule Digital Memories database: its capsule schema differs. No user data or session key is included in this ZIP.

## Use the new features
Create/edit a draft and save it. On its preview, click Choose opening date & seal. Select a future local date/time or use In 2 minutes for a demonstration. Tick the confirmation box and seal. The page shows a countdown and opens the memory after the server confirms it is due.

Sealed messages and files are unavailable before that time. Sealed capsules cannot be changed or deleted, even after opening. Drafts remain editable. Sealing requires JavaScript for local-to-UTC conversion; reading due capsules works without JavaScript by refreshing the page.

## Uploads
JPG/JPEG, PNG, GIF, WebP, MP4 and WebM; up to 10 attachments per capsule. Maximum 50 MB request per save. Checks cover extensions and basic headers, not malware scanning or complete media decoding. Files download rather than play inline.

## Local limits
Your computer is the server and its clock controls opening. Changing its clock or accessing the files/database directly can bypass app-level restrictions. Stored content is not encrypted. There is no email verification, password reset, login rate limiting, sharing, or email/background notification in this sprint. Back up instance if you want to keep memories.

## Tests
```
.venv\Scripts\python.exe -m unittest discover -s tests -v
```
On macOS/Linux use `.venv/bin/python`. The test suite checks earlier account/draft features plus timing, access control and migration. Manual Windows and visual browser checks remain necessary.

## GitHub
Upload extracted source files, templates, static assets, tests and docs. Keep `.gitignore`. Never upload instance/, .venv/ or __pycache__/, including browser drag-and-drop. Keep your existing .git directory and actual Scrum records when updating a repository.

Suggested commit: `Add Sprint 3 capsule sealing, countdown and timed unlocking`.

See docs/sprint-3-guide.md for the developer walkthrough, scope and demo. Earlier sprint guides are historical references. docs/sprint-3-sequence-diagrams.md contains the new UML sequence diagrams.


## Project name and existing database
The project is named Time Capsule Digital Memories throughout the source and interface.
The database is now `instance/time_capsule_digital_memories.db`.
To upgrade from your previous Sprint 3 version, stop it, back up the whole folder,
extract this version, and copy the entire old `instance/` folder beside `app.py`.
If there is one existing `.db` file and the new filename is absent, the app copies
its contents using SQLite backup, then removes the old database file. Accounts,
capsules and uploaded attachments are retained. Keep your separate backup until
successful login and capsule access have been checked. Do not run both versions
against the same instance folder during migration.
