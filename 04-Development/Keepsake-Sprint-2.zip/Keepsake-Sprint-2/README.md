# Keepsake — Sprints 1 and 2

This cumulative local Python Flask application includes Sprint 1 accounts and frontend design, plus Sprint 2 private capsule drafts.

## Included
- Welcome page, registration, login, logout and protected dashboard.
- Create a capsule with title, message and one of three cover colors.
- Attach JPG/JPEG, PNG, GIF, WebP, MP4 or WebM files.
- View and edit your own drafts; existing attachments remain on edits.
- Download your own attachments.
- Delete a draft through an explicit confirmation page, including its attachments.
- Owner checks on all draft and attachment routes; password hashing and CSRF protection.

Opening dates, sealing, countdowns, sharing and unlock notifications are not part of this Sprint 2 package.

## Upgrade from the supplied Sprint 1 version
1. Stop the running app with Ctrl+C in its terminal.
2. Back up your existing Sprint 1 folder, especially `instance/`.
3. Extract `Keepsake-Sprint-2.zip` into a NEW folder.
4. To keep your accounts, COPY your old `instance/` folder into the new `Keepsake-Sprint-2` folder. It should be beside `app.py`. Do not move your only copy.
5. Double-click `start_windows.bat` in the new folder.
6. Open http://127.0.0.1:5000 and log in with your existing account.

The application adds capsule and attachment tables automatically. It does not delete or replace the users table. Copying the secret key also preserves session signing continuity. If you do not copy instance, the app creates a fresh empty database.

This upgrade is tested against the supplied Sprint 1 schema. Do not copy the database from the separate COMPLETE Keepsake version into this sprint package: that version has a different capsule schema.

## Fresh installation
Install Python 3.11 or newer, extract the ZIP, and double-click `start_windows.bat`. The launcher installs Flask; internet access is needed for dependency installation. Keep its terminal open while using the website.

Manual Windows commands, from the extracted folder:
```
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```
macOS/Linux:
```
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```
Only one instance can use port 5000 at a time. The development server binds to this computer only.

## Uploads and storage
Each draft allows up to 10 attachments total. Each save allows a request of up to 50 MB; JavaScript limits selected files to 49 MB to leave room for the form. Files are checked for extension and basic header signatures. This is not full media decoding or malware scanning. Attachments download rather than playing inline.

Saved drafts, accounts and uploads live in `instance/`. They are private through application access checks, but are not encrypted on disk. Someone with direct access to your local files can read them. There is no email verification, password reset, or login rate limiting in this educational local version.

## Files
- `app.py`: accounts, additive schema setup, draft CRUD and upload validation.
- `templates/`: welcome, accounts, dashboard, editor, draft preview and deletion confirmation.
- `static/style.css`: indented CSS with the shared design and Sprint 2 additions.
- `static/app.js`: selected-file feedback and client-side limits.
- `tests/test_accounts.py`: Sprint 1 regression checks.
- `tests/test_capsules.py`: Sprint 2 lifecycle, access and upgrade checks.
- `docs/sprint-2-guide.md`: changed files, demonstration steps and developer explanation.
- `docs/sprint-1-guide.md`: original Sprint 1 reference; current test results are in the Sprint 2 guide.

## Run tests
```
.venv\Scripts\python.exe -m unittest discover -s tests -v
```
On macOS/Linux use `.venv/bin/python`.

## GitHub
Upload the source files and folders, not only the ZIP. Keep `.gitignore`. Do not upload `instance/`, `.venv/` or `__pycache__/`, including through drag-and-drop. Preserve your existing `.git/` directory and actual Scrum records when updating an existing checkout. This package does not contain meeting evidence or fabricated progress.

Suggested commit message: `Add Sprint 2 capsule drafts, uploads, editing and deletion`.
