// Show the selected filenames and catch oversized selections before uploading.
// Python performs its own validation, even when JavaScript is disabled.
const uploadInput = document.getElementById('files');
const filenameList = document.getElementById('file-list');

if (uploadInput && filenameList) {
    uploadInput.addEventListener('change', () => {
        const selectedFiles = Array.from(uploadInput.files);
        const existingCount = Number(uploadInput.dataset.existing || 0);
        const totalBytes = selectedFiles.reduce((sum, file) => sum + file.size, 0);
        let error = '';

        if (existingCount + selectedFiles.length > 10) {
            error = 'Each capsule can have up to 10 attachments in total.';
        } else if (totalBytes > 49 * 1024 * 1024) {
            // Leave space for the message and multipart form overhead.
            error = 'Choose files smaller than 49 MB in total for this save.';
        }

        uploadInput.setCustomValidity(error);
        filenameList.textContent = error || (
            selectedFiles.length
                ? selectedFiles.map(file => file.name).join(' · ')
                : 'JPG, PNG, GIF, WebP, MP4, WebM'
        );
    });
}

// Deletion uses a server-rendered confirmation page, so it also works without JS.
